import json
import matplotlib.pyplot as plt
from pathlib import Path
import numpy as np
import re

def parse_json_log(log_path):
    """
    Parses RF-DETR style JSON logs and extracts all required metrics.
    Works perfectly for logs like the one you uploaded.
    """
    log_path = Path(log_path)
    if not log_path.exists():
        raise FileNotFoundError(f"❌ Log file not found: {log_path}")

    epochs, train_loss, test_loss = [], [], []
    precision, recall, map50, map95 = [], [], [], []

    json_pattern = re.compile(r"\{.*\}")

    with open(log_path, "r", encoding="utf-8") as f:
        for line in f:
            match = json_pattern.search(line)
            if not match:
                continue
            try:
                data = json.loads(match.group())
            except json.JSONDecodeError:
                continue

            # Extract epoch
            if "epoch" in data:
                epochs.append(data["epoch"])
            elif "all_best_ep" in data:
                epochs.append(len(epochs) + 1)

            # Train/Test Loss
            if "train_loss" in data:
                train_loss.append(float(data["train_loss"]))
            if "test_loss" in data:
                test_loss.append(float(data["test_loss"]))
            if "ema_test_loss" in data:
                test_loss.append(float(data["ema_test_loss"]))

            # Precision, Recall, mAP
            for k in ["ema_test_results_json", "test_results_json"]:
                if k in data and isinstance(data[k], dict):
                    res = data[k]
                    precision.append(res.get("precision", np.nan))
                    recall.append(res.get("recall", np.nan))
                    map50.append(res.get("map@50", np.nan))
                    map95.append(res.get("map@50:95", np.nan))

    n = max(len(train_loss), len(test_loss), len(precision), len(map50))
    epochs = list(range(1, n + 1))

    print(f"✅ Parsed {len(epochs)} epochs")
    print(f"Metrics available: train_loss={len(train_loss)}, test_loss={len(test_loss)}, "
          f"precision={len(precision)}, recall={len(recall)}, map50={len(map50)}")

    return {
        "epoch": epochs,
        "train_loss": train_loss,
        "test_loss": test_loss,
        "precision": precision,
        "recall": recall,
        "map50": map50,
        "map95": map95
    }


def plot_metrics(data, save_dir):
    """
    Plots combined and individual metric curves, saving to disk.
    """
    plt.style.use("seaborn-v0_8-darkgrid")
    save_dir = Path(save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    epochs = np.array(data["epoch"])

    # ✅ Combined Train vs Test Loss
    plt.figure(figsize=(8, 5))
    if len(data["train_loss"]) > 0:
        plt.plot(epochs[:len(data["train_loss"])], data["train_loss"],
                 marker="o", linewidth=2, label="Train Loss")
    if len(data["test_loss"]) > 0:
        plt.plot(epochs[:len(data["test_loss"])], data["test_loss"],
                 marker="o", linewidth=2, label="Test Loss")
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.title("Training vs Test Loss Curve")
    plt.legend()
    plt.tight_layout()
    loss_path = save_dir / "train_vs_test_loss.png"
    plt.savefig(loss_path)
    plt.close()
    print(f"✅ Saved: {loss_path}")

    # ✅ Combined Precision and Recall
    if len(data["precision"]) > 0 or len(data["recall"]) > 0:
        plt.figure(figsize=(8, 5))
        if len(data["precision"]) > 0:
            plt.plot(epochs[:len(data["precision"])], data["precision"],
                     marker="o", linewidth=2, label="Precision")
        if len(data["recall"]) > 0:
            plt.plot(epochs[:len(data["recall"])], data["recall"],
                     marker="o", linewidth=2, label="Recall")
        plt.xlabel("Epoch")
        plt.ylabel("Score")
        plt.title("Precision & Recall Curve")
        plt.legend()
        plt.tight_layout()
        pr_path = save_dir / "precision_recall.png"
        plt.savefig(pr_path)
        plt.close()
        print(f"✅ Saved: {pr_path}")

    # ✅ mAP@50
    if len(data["map50"]) > 0:
        plt.figure(figsize=(8, 5))
        plt.plot(epochs[:len(data["map50"])], data["map50"],
                 marker="o", linewidth=2, color="green", label="mAP@50")
        plt.xlabel("Epoch")
        plt.ylabel("mAP@50")
        plt.title("mAP@50 Curve")
        plt.legend()
        plt.tight_layout()
        map50_path = save_dir / "map50.png"
        plt.savefig(map50_path)
        plt.close()
        print(f"✅ Saved: {map50_path}")

    # ✅ mAP@50:95
    if len(data["map95"]) > 0:
        plt.figure(figsize=(8, 5))
        plt.plot(epochs[:len(data["map95"])], data["map95"],
                 marker="o", linewidth=2, color="purple", label="mAP@50:95")
        plt.xlabel("Epoch")
        plt.ylabel("mAP@50:95")
        plt.title("mAP@50:95 Curve")
        plt.legend()
        plt.tight_layout()
        map95_path = save_dir / "map95.png"
        plt.savefig(map95_path)
        plt.close()
        print(f"✅ Saved: {map95_path}")

    print(f"\n✅ All plots saved to {save_dir.resolve()}")


if __name__ == "__main__":
    log_path = r"C:/Users/MSIS/Desktop/PLots/log.txt"
    output_dir = r"C:/Users/MSIS/Desktop/PLots/plots"

    data = parse_json_log(log_path)
    plot_metrics(data, output_dir)
